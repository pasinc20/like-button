<?php
/*
Plugin Name: Product Likes
Description: Allows logged in users to "like" a product and displays the number of likes beside the button.
Version: 1.0
Author: Your Name
*/

global $wpdb;
$charset_collate = $wpdb->get_charset_collate();
$table_name = $wpdb->prefix . 'product_likes';

$sql = "CREATE TABLE $table_name (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  product_id bigint(20) NOT NULL,
  user_id bigint(20) NOT NULL,
  PRIMARY KEY  (id)
) $charset_collate;";

require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );

function like_product() {
  if ( ! is_user_logged_in() ) {
    return;
  }
  global $wpdb;
  $table_name = $wpdb->prefix . 'product_likes';
  $product_id = intval( $_POST['product_id'] );
  $user_id = get_current_user_id();
  $exists = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table_name WHERE product_id = %d AND user_id = %d", $product_id, $user_id ) );
  if ( ! $exists ) {
    $wpdb->insert(
      $table_name,
      array(
        'product_id' => $product_id,
        'user_id' => $user_id,
      ),
      array(
        '%d',
        '%d',
      )
    );
  } else {
    // If the user has already liked the product, delete the like from the database
    $wpdb->delete(
      $table_name,
      array(
        'product_id' => $product_id,
        'user_id' => $user_id,
      ),
      array(
        '%d',
        '%d',
      )
    );
  }
  // Return the updated like count for the product
  $likes = get_product_likes( $product_id );
  wp_send_json_success( array( 'likes' => $likes ) );
}


add_action( 'wp_ajax_like_product', 'like_product' );

function get_product_likes( $product_id ) {
  global $wpdb;
  $table_name = $wpdb->prefix . 'product_likes';
  $count = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table_name WHERE product_id = %d", $product_id ) );
  return intval( $count );
}

add_action( 'wp_enqueue_scripts', 'enqueue_scripts' );
function enqueue_scripts() {
  wp_enqueue_script( 'product-likes', plugin_dir_url( __FILE__ ) . 'product-likes.js', array( 'jquery' ), '1.0', true );
  wp_localize_script( 'product-likes', 'product_likes_params', array(
    'ajax_url' => admin_url( 'admin-ajax.php' ),
    'nonce' => wp_create_nonce( 'like_product_nonce' ),
  ) );
}

add_action( 'woocommerce_after_add_to_cart_button', 'display_like_button' );
function display_like_button() {
  global $product;
  $product_id = $product->get_id();
  $likes = get_product_likes( $product_id );
  wp_nonce_field( 'like_product_' . $product_id, 'like_product_nonce' );
  include 'like-button-template.php';
}
