jQuery( function( $ ) {
  $( '.like-button' ).on( 'click', function( e ) {
    e.preventDefault();
    var $button = $( this );
    var product_id = $button.data( 'product-id' );
    $.ajax( {
      type: 'POST',
      url: product_likes_params.ajax_url,
      data: {
        action: 'like_product',
        product_id: product_id,
        nonce: product_likes_params.nonce,
      },
      success: function( response ) {
        if ( response.success ) {
          // Update the like count on the page
          $button.find( '.like-count' ).text( response.data.likes );
          // Toggle the "liked" class on the button
          $button.toggleClass( 'liked' );
          if ( $button.hasClass( 'liked' ) ) {
            $button.find( '.like-text' ).text( product_likes_params.unlike_text );
          } else {
            $button.find( '.like-text' ).text( product_likes_params.like_text );
          }
        } else {
          // Display a message or animate the button to indicate that the user has already liked the product
          $button.addClass( 'liked' );
          $button.find( '.like-text' ).text( product_likes_params.already_liked_text );
        }
      },
    } );
  } );
} );

