<button class="like-button" data-product-id="<?php echo esc_attr( $product_id ); ?>">
  <span class="like-count"><?php echo esc_html( $likes ); ?></span>
  &#x2764;
</button>


